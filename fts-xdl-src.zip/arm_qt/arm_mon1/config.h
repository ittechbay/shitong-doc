#ifndef CONFIG_H
#define CONFIG_H

//编译平台选择
//#define ST_COMPILE_WIN32  //编译成windows版本
#define ST_COMPILE_DEVICE  //编译成时统设备版本

#define ST_LOG_FILE_NAME "/work/st.log"

#define MAX_SNMP_STRING_LEN 128




#endif // CONFIG_H

